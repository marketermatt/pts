;mw.loader.state({"site":"ready"});

/* cache key: wpbakery_wiki:resourceloader:filter:minify-js:7:fba29bdcb828747c2ed17376d02217ef */
